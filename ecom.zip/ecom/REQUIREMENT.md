# Challenge:
We would like you to build the frontend of a small webapp based on the wireframes attached along with this mail. We've also attached a zip file containing the assets.

# Webapp description:
* The Browse page where you can see a grid of products
* The Product detail page (PDP) where you can see the details of a product
* The Cart page where you can see all the items you've added to cart
* Clicking on a product in Cart or Browse page should show the PDP page
* Clicking on Cart or Browse button at top should take the user to the respective pages
* Clicking on Brands or Price filters in sidebar should show only the products that match the values
* Use the mock data and assets provided in the zip file to populate the above filters and products views

# Requirements:
* Use HTML, CSS, and JavaScript
* Use React for UI
* Prefer Flexbox for CSS layouts
* Don’t use other DOM manipulation libs like jQuery or utility libs like underscore or lodash etc
* Don't use any HTML or CSS frameworks like bootstrap, skeleton etc

# Guidelines:
* This challenge is mainly about frontend development. Backend is not necessary.
* Keep things simple - Try to avoid libs that add unnecessary complexity.

# Delivery:
Upon completion of the project, please provide a link to download the source code, along with instructions to run the app locally

# Evaluation criteria:
* Full completion of the challenge

# Bonus points:
* UI enhancement from wireframes