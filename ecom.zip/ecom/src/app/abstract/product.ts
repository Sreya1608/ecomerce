export class Product {
    public id: number = undefined;
    public name: string = undefined;
    public price: number = undefined;
    public brand: string = undefined;
    public desc: string = undefined;
    public measurement: string = undefined;
    public image: string = undefined;
}
